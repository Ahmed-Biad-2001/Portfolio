windowSize = (1366,768)
fullscreen = True
cursorSpeed = 1
masterVolume = 1
ips = 60
levelFolder = "Levels/"